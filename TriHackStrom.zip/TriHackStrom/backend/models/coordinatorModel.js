const mongoose = require("mongoose");

const coordinatorSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    assignedMentors: [{ type: mongoose.Schema.Types.ObjectId, ref: "Mentor" }],
});

module.exports = mongoose.model("Coordinator", coordinatorSchema);
