const mongoose = require("mongoose");

const internSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    mentor: { type: mongoose.Schema.Types.ObjectId, ref: "Mentor" },
    company: { type: String, required: true },
    progressReports: [{ type: mongoose.Schema.Types.ObjectId, ref: "Report" }],
});

module.exports = mongoose.model("Intern", internSchema);
