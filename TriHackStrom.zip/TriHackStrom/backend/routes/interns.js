const express = require("express");
const router = express.Router();
const Intern = require("../models/internModel");

// Get all interns
router.get("/", async (req, res) => {
    try {
        const interns = await Intern.find().populate("mentor progressReports");
        res.status(200).json(interns);
    } catch (err) {
        res.status(500).json({ error: "Failed to fetch interns" });
    }
});

// Add a new intern
router.post("/", async (req, res) => {
    try {
        const newIntern = new Intern(req.body);
        await newIntern.save();
        res.status(201).json(newIntern);
    } catch (err) {
        res.status(500).json({ error: "Failed to create intern" });
    }
});

module.exports = router;
