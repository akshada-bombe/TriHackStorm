const express = require("express");
const router = express.Router();
const Mentor = require("../models/mentorModel");

// Get all mentors
router.get("/", async (req, res) => {
    try {
        const mentors = await Mentor.find().populate("assignedInterns");
        res.status(200).json(mentors);
    } catch (err) {
        res.status(500).json({ error: "Failed to fetch mentors" });
    }
});

module.exports = router;
