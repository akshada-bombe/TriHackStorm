const mongoose = require("mongoose");
const connectDB = require("./config/dbConfig");
const Intern = require("./models/internModel");
const Mentor = require("./models/mentorModel");
const Coordinator = require("./models/coordinatorModel"); // Import Coordinator model

const seedData = async () => {
    try {
        await connectDB();

        // Sample Mentors
        const mentor1 = await Mentor.create({ name: "Dr. Aditi Sharma", email: "aditi.sharma@university.edu" });
        const mentor2 = await Mentor.create({ name: "Dr. Rahul Mehta", email: "rahul.mehta@university.edu" });

        // Sample Interns
        await Intern.create({ name: "Aman Gupta", email: "aman.gupta@example.com", mentor: mentor1._id, company: "TCS" });
        await Intern.create({ name: "Priya Singh", email: "priya.singh@example.com", mentor: mentor2._id, company: "Infosys" });

        // Sample Coordinators
        await Coordinator.create({
            name: "Dr. Meera Iyer",
            email: "meera.iyer@university.edu",
            assignedMentors: [mentor1._id, mentor2._id],
        });

        console.log("Sample data inserted successfully!");
        process.exit();
    } catch (err) {
        console.error("Failed to seed data:", err);
        process.exit(1);
    }
};

seedData();
