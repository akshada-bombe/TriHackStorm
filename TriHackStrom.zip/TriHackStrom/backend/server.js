const express = require("express");
const connectDB = require("./config/dbConfig");

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());

// Connect to MongoDB
connectDB();

// Routes
app.use("/api/interns", require("./routes/interns"));
app.use("/api/mentors", require("./routes/mentors"));

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
