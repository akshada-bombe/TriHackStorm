-- Inserting sample data into Mentors table
INSERT INTO mentors (id, name, email, phone, department) VALUES
(1, 'Ravi Kumar', 'ravi.kumar@tcs.com', '9876543210', 'Software Engineering'),
(2, 'Priya Verma', 'priya.verma@infosys.com', '9876543211', 'Data Science'),
(3, 'Ankur Shah', 'ankur.shah@wipro.com', '9876543212', 'Network Security'),
(4, 'Neha Gupta', 'neha.gupta@accenture.com', '9876543213', 'Cloud Computing'),
(5, 'Vikram Singh', 'vikram.singh@cognizant.com', '9876543214', 'AI and Machine Learning');

-- Inserting sample data into Interns table
INSERT INTO interns (id, name, email, startDate, companyName, mentorId, stipend, offerLetter, location) VALUES
(1, 'Raj Sharma', 'raj.sharma@example.com', '2024-06-01', 'Tata Consultancy Services', 1, 15000, 'TCS_Offer_Letter.pdf', 'Mumbai'),
(2, 'Anita Yadav', 'anita.yadav@example.com', '2024-07-01', 'Infosys', 2, 14000, 'Infosys_Offer_Letter.pdf', 'Bengaluru'),
(3, 'Suresh Reddy', 'suresh.reddy@example.com', '2024-06-15', 'Wipro', 3, 13000, 'Wipro_Offer_Letter.pdf', 'Hyderabad'),
(4, 'Priya Jain', 'priya.jain@example.com', '2024-05-10', 'Accenture', 4, 16000, 'Accenture_Offer_Letter.pdf', 'Chennai'),
(5, 'Vikas Singh', 'vikas.singh@example.com', '2024-07-01', 'Cognizant', 5, 15500, 'Cognizant_Offer_Letter.pdf', 'Pune');

-- Inserting sample data into Coordinators table
INSERT INTO coordinators (id, name, email, department) VALUES
(1, 'Dr. Shweta Singh', 'shweta.singh@university.com', 'Computer Science'),
(2, 'Prof. Amit Agarwal', 'amit.agarwal@university.com', 'Information Technology'),
(3, 'Dr. Ramesh Kumar', 'ramesh.kumar@university.com', 'Electrical Engineering');

-- Assigning mentors to coordinators (many-to-many relationship example)
INSERT INTO coordinator_mentor (coordinatorId, mentorId) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 5);
