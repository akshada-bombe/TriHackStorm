// Base URL for the backend
const BASE_URL = "http://localhost:5000";

// Fetch list of interns
async function fetchInterns() {
    try {
        const response = await fetch(`${BASE_URL}/api/interns`);
        const data = await response.json();
        console.log(data); // Handle data (e.g., update UI)
    } catch (error) {
        console.error("Error fetching interns:", error);
    }
}

fetchInterns();
